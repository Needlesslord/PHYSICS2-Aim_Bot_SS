%Test_Verlet
%	2D particle physics integrator based on 2n order Verlet scheme
%
%David de la Torre
%December 2019

%% Configuration parameters

% Simulation options
m = 1.0; % Particle mass [kg]
S = 0.1; % Particle front surface [m^2]
Cd = 1.0; % Particle drag coefficient [-]
bc = 0.95; % Particle bounce coefficient / restoration factor [0-1]
rho = 1.225; % World air density [kg/m3]
g0 = [0.0,-9.81]; % World gravity acceleration (ax,ay) [m/s2]
wind = [5.0,0.0]; % World wind velocity vector (vx,vy) [m/s]
ww = 30; % World width [m]
wh = 10; % World height [m]
fps = 30; % Game frames per second [fps]
tf = 10; % Game final simulation time [seconds]
ff = tf * fps; % Game total simulation frames (assume constant fps)

% Particle initial state
x = [0,0]; % Particle initial position (x,y) [m]
v = [10,15]; % Particle initial velocity (vx,vy) [m/s]

% Matlab figure size
figW = 800; % Figure width [px]
figH = 600; % Figure height [px]

%% Create figure
% The figure will have 2x2 divisions:
%   Partition 1:2 (top row) will allocate the main simulation plot
%   Partition 3 (down-left) will allocate the velocity debug plot
%   Partition 4 (down-right) will allocate the Aero Fd debug plot

% Create new figure
fh = figure();

% Resize figure to cfg dimensions
fh.Position = [0,0,figW,figH];

% Simulation plot
ah_sim = subplot(2,2,[1,2]); % Main simulation plot
hold on; grid on; box on; axis equal; % Plot options
title('Scenario'); % Title
xlabel('Position X [m]'); % Label of x-axis
ylabel('Position Y [m]'); % Label of y-axis
xlim([0,ww]); % Limits of x-axis: size of scenario
ylim([0,wh]); % Limits of y-axis: size of scenario

% Debug plot: Velocity
ah_velo = subplot(2,2,3); % Debug velocity plot
hold on; grid on; box on; % Plot options
title('Velocity'); % Title
xlabel('Frame [#]'); % Label of x-axis
ylabel('Velocity [m/s]'); % Label of y-axis
xlim([0,ff]); % Limits of x-axis: total number of frames

% Debug plot: Drag
ah_drag = subplot(2,2,4); % Debug Aero Fd plot
hold on; grid on; box on; % Plot options
title('Aerodynamic drag force'); % Title
xlabel('Frame [#]'); % Label of x-axis
ylabel('Force [N]'); % Label of y-axis
xlim([0,ff]); % Limits of x-axis: total number of frames

%% Main game loop
for i=1:ff % Advance frames
    
    % Sync game-global fps -> compute frame time step
    dt = 1.0 / fps;
    
    % Compute gravity force on particle
    Fg = m * g0;
    
    % Compute aerodynamic drag force on particle
    vw = v - wind; % Particle velocity (wind reference frame)
    vu = vw / norm(vw); % Unitary particle-wind velocity vector
    Fd = 0.5 * rho * vw .* vw * S * Cd .* -vu; % Drag force vector
    
    % Compute total force (d'Alembert principle)
    F = Fg + Fd;
    
    % Compute acceleration of particle (2nd Newton's law)
    a = F / m;
    
    % Integrate position and velocity (2nd order Verlet)
    x = x + v * dt + 0.5 * a * dt * dt;
    v = v + a * dt;
    
    % Detect collisions
    if x(1) < 0,  x(1) = 0;  v(1) = - bc * v(1); end % Left wall
    if x(1) > ww, x(1) = ww; v(1) = - bc * v(1); end % Right wall
    if x(2) < 0,  x(2) = 0;  v(2) = - bc * v(2); end % Bottom wall
    if x(2) > wh, x(2) = wh; v(2) = - bc * v(2); end % Top wall
    
    % Plot results
    plot(ah_sim,x(1),x(2),'bo'); % Particle position
    plot(ah_velo,i,v(1),'b.',i,v(2),'r.'); % Particle velocity
    plot(ah_drag,i,Fd(1),'b.',i,Fd(2),'r.'); % Drag force
    drawnow; % Flush all pending graphics operations
    
end

